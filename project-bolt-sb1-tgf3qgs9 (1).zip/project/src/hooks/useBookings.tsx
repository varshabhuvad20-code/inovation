import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Booking } from '@/types';
import { loadBookings, saveBookings } from '@/lib/storage';

interface BookingsContextValue {
  bookings: Booking[];
  addBooking: (b: Booking) => void;
  updateBooking: (id: string, patch: Partial<Booking>) => void;
  removeBooking: (id: string) => void;
}

const BookingsContext = createContext<BookingsContextValue | null>(null);

export function BookingsProvider({ children }: { children: ReactNode }) {
  const [bookings, setBookings] = useState<Booking[]>(() => loadBookings());

  useEffect(() => {
    saveBookings(bookings);
  }, [bookings]);

  const value = useMemo<BookingsContextValue>(
    () => ({
      bookings,
      addBooking: (b) => setBookings((prev) => [b, ...prev]),
      updateBooking: (id, patch) =>
        setBookings((prev) => prev.map((b) => (b.id === id ? { ...b, ...patch } : b))),
      removeBooking: (id) => setBookings((prev) => prev.filter((b) => b.id !== id)),
    }),
    [bookings],
  );

  return <BookingsContext.Provider value={value}>{children}</BookingsContext.Provider>;
}

export function useBookings() {
  const ctx = useContext(BookingsContext);
  if (!ctx) throw new Error('useBookings must be used within BookingsProvider');
  return ctx;
}
