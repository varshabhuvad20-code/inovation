export type ServiceId =
  | 'general-consultation'
  | 'dental-consultation'
  | 'physiotherapy'
  | 'counseling'
  | 'personal-consultation';

export interface Service {
  id: ServiceId;
  name: string;
  description: string;
  durationMinutes: number;
  icon: string; // lucide icon name
}

export interface Provider {
  id: string;
  name: string;
  role: string;
  specialization: string;
  serviceIds: ServiceId[];
  initials: string;
  accent: string; // tailwind gradient classes for avatar
  availableToday: boolean;
}

export type SlotState = 'available' | 'unavailable';

export interface TimeSlot {
  time: string; // "09:00 AM"
  state: SlotState;
}

export type BookingStatus = 'upcoming' | 'completed' | 'cancelled';

export interface Booking {
  id: string;
  reference: string;
  serviceId: ServiceId;
  serviceName: string;
  providerId: string;
  providerName: string;
  date: string; // ISO yyyy-mm-dd
  time: string; // "09:00 AM"
  name: string;
  email: string;
  phone: string;
  notes?: string;
  status: BookingStatus;
  createdAt: string; // ISO timestamp
}
