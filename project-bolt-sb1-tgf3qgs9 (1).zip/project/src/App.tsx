import { useEffect, useState } from 'react';
import { BookingsProvider } from '@/hooks/useBookings';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import BookingFlow from '@/components/BookingFlow';
import MyBookings from '@/components/MyBookings';
import HowItWorks from '@/components/HowItWorks';
import Benefits from '@/components/Benefits';
import FAQ from '@/components/FAQ';
import Footer from '@/components/Footer';
import About from '@/components/About';
import SuccessModal from '@/components/SuccessModal';
import type { Booking } from '@/types';

type View = 'home' | 'book' | 'bookings' | 'about';

function App() {
  const [view, setView] = useState<View>('home');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [successBooking, setSuccessBooking] = useState<Booking | null>(null);
  const [flowKey, setFlowKey] = useState(0);

  const navigate = (v: View) => {
    setView(v);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const resetFlow = () => setFlowKey((k) => k + 1);

  useEffect(() => {
    document.title =
      view === 'book'
        ? 'Book an Appointment — AppointEase'
        : view === 'bookings'
        ? 'My Bookings — AppointEase'
        : view === 'about'
        ? 'About — AppointEase'
        : 'AppointEase — Book Your Appointment';
  }, [view]);

  return (
    <BookingsProvider>
      <div className="flex min-h-screen flex-col">
        <Navbar
          view={view}
          onNavigate={navigate}
          mobileOpen={mobileOpen}
          setMobileOpen={setMobileOpen}
        />

        <main className="flex-1">
          {view === 'home' && (
            <>
              <Hero onBook={() => navigate('book')} onMyBookings={() => navigate('bookings')} />
              <div id="book-section">
                <BookingFlow
                  key={flowKey}
                  onComplete={(b) => {
                    setSuccessBooking(b);
                    resetFlow();
                  }}
                  onCancel={() => navigate('home')}
                />
              </div>
              <HowItWorks />
              <Benefits />
              <FAQ />
            </>
          )}

          {view === 'book' && (
            <BookingFlow
              key={flowKey}
              onComplete={(b) => {
                setSuccessBooking(b);
                resetFlow();
              }}
              onCancel={() => navigate('home')}
            />
          )}

          {view === 'bookings' && <MyBookings onBookNew={() => navigate('book')} />}

          {view === 'about' && <About onBook={() => navigate('book')} />}
        </main>

        <Footer onNavigate={navigate} />

        {successBooking && (
          <SuccessModal
            booking={successBooking}
            onView={() => {
              setSuccessBooking(null);
              navigate('bookings');
            }}
            onBookAnother={() => {
              setSuccessBooking(null);
              resetFlow();
              navigate('book');
            }}
            onClose={() => setSuccessBooking(null)}
          />
        )}
      </div>
    </BookingsProvider>
  );
}

export default App;
