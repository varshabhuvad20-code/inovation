import type { Provider, Service, ServiceId, TimeSlot } from './types';

export const SERVICES: Service[] = [
  {
    id: 'general-consultation',
    name: 'General Consultation',
    description: 'A broad check-in for everyday concerns and general advice.',
    durationMinutes: 30,
    icon: 'Stethoscope',
  },
  {
    id: 'dental-consultation',
    name: 'Dental Consultation',
    description: 'Oral health assessment, cleaning, and care planning.',
    durationMinutes: 45,
    icon: 'Smile',
  },
  {
    id: 'physiotherapy',
    name: 'Physiotherapy',
    description: 'Movement assessment and guided physical therapy.',
    durationMinutes: 60,
    icon: 'Activity',
  },
  {
    id: 'counseling',
    name: 'Counseling',
    description: 'A private, supportive conversation with a counselor.',
    durationMinutes: 50,
    icon: 'HeartHandshake',
  },
  {
    id: 'personal-consultation',
    name: 'Personal Consultation',
    description: 'One-on-one planning session for personal goals.',
    durationMinutes: 40,
    icon: 'UserRound',
  },
];

export const PROVIDERS: Provider[] = [
  {
    id: 'p1',
    name: 'Dr. Amara Okafor',
    role: 'General Practitioner',
    specialization: 'General Consultation',
    serviceIds: ['general-consultation', 'personal-consultation'],
    initials: 'AO',
    accent: 'from-sky-500 to-blue-600',
    availableToday: true,
  },
  {
    id: 'p2',
    name: 'Dr. Marcus Bell',
    role: 'Dental Surgeon',
    specialization: 'Dental Care',
    serviceIds: ['dental-consultation'],
    initials: 'MB',
    accent: 'from-teal-500 to-emerald-600',
    availableToday: true,
  },
  {
    id: 'p3',
    name: 'Sofia Reyes, PT',
    role: 'Physiotherapist',
    specialization: 'Rehabilitation & Movement',
    serviceIds: ['physiotherapy'],
    initials: 'SR',
    accent: 'from-orange-500 to-amber-600',
    availableToday: false,
  },
  {
    id: 'p4',
    name: 'Dr. Lena Hoffmann',
    role: 'Counseling Psychologist',
    specialization: 'Counseling',
    serviceIds: ['counseling', 'personal-consultation'],
    initials: 'LH',
    accent: 'from-rose-500 to-pink-600',
    availableToday: true,
  },
  {
    id: 'p5',
    name: 'Dr. Idris Khan',
    role: 'General Practitioner',
    specialization: 'Preventive Care',
    serviceIds: ['general-consultation'],
    initials: 'IK',
    accent: 'from-indigo-500 to-violet-600',
    availableToday: true,
  },
];

export const BASE_SLOTS: string[] = [
  '09:00 AM',
  '09:30 AM',
  '10:00 AM',
  '10:30 AM',
  '11:00 AM',
  '11:30 AM',
  '02:00 PM',
  '02:30 PM',
  '03:00 PM',
  '03:30 PM',
  '04:00 PM',
  '04:30 PM',
];

// Deterministic pseudo-random per date+provider so the demo feels stable.
function seededUnavailable(dateStr: string, providerId: string): Set<string> {
  const seed = [...dateStr + providerId].reduce((a, c) => a + c.charCodeAt(0), 0);
  const rng = (n: number) => {
    const x = Math.sin(n) * 10000;
    return x - Math.floor(x);
  };
  const blocked = new Set<string>();
  BASE_SLOTS.forEach((slot, i) => {
    if (rng(seed + i) > 0.72) blocked.add(slot);
  });
  return blocked;
}

export function getSlotsFor(dateStr: string, providerId: string, takenTimes: string[]): TimeSlot[] {
  const blocked = seededUnavailable(dateStr, providerId);
  const taken = new Set(takenTimes);
  return BASE_SLOTS.map((time) => {
    if (blocked.has(time) || taken.has(time)) {
      return { time, state: 'unavailable' as const };
    }
    return { time, state: 'available' as const };
  });
}

export function serviceById(id: ServiceId): Service | undefined {
  return SERVICES.find((s) => s.id === id);
}

export function providerById(id: string): Provider | undefined {
  return PROVIDERS.find((p) => p.id === id);
}
