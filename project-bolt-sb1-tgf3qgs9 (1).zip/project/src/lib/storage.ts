import type { Booking } from '@/types';

const STORAGE_KEY = 'appointease.bookings.v1';

export function loadBookings(): Booking[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Booking[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveBookings(bookings: Booking[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(bookings));
  } catch {
    // ignore quota errors in this prototype
  }
}

export function generateReference(): string {
  const alpha = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const nums = '0123456789';
  let ref = 'AE-';
  for (let i = 0; i < 3; i++) ref += alpha[Math.floor(Math.random() * alpha.length)];
  ref += '-';
  for (let i = 0; i < 4; i++) ref += nums[Math.floor(Math.random() * nums.length)];
  return ref;
}

export function newId(): string {
  return `b_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}
