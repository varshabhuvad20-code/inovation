import { CalendarCheck, Mail, MapPin, Phone } from 'lucide-react';

type View = 'home' | 'book' | 'bookings' | 'about';

interface FooterProps {
  onNavigate: (view: View) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="border-t border-slate-200 bg-slate-50">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-4">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-600 text-white">
                <CalendarCheck size={20} strokeWidth={2.5} />
              </span>
              <span className="font-display text-lg font-extrabold tracking-tight text-slate-900">
                Appoint<span className="text-brand-600">Ease</span>
              </span>
            </div>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-slate-600">
              A simple online appointment-booking system. Choose a service, pick a convenient time,
              and manage your bookings from one place.
            </p>
            <p className="mt-4 text-xs text-slate-400">
              Prototype / demo — provider names and data are fictional.
            </p>
          </div>

          <div>
            <h4 className="font-display text-sm font-bold text-slate-900">Navigate</h4>
            <ul className="mt-3 space-y-2 text-sm">
              {([
                ['home', 'Home'],
                ['book', 'Book Appointment'],
                ['bookings', 'My Bookings'],
                ['about', 'About'],
              ] as [View, string][]).map(([v, label]) => (
                <li key={v}>
                  <button
                    onClick={() => onNavigate(v)}
                    className="text-slate-600 transition-colors hover:text-brand-600"
                  >
                    {label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-display text-sm font-bold text-slate-900">Contact</h4>
            <ul className="mt-3 space-y-2.5 text-sm text-slate-600">
              <li className="flex items-center gap-2">
                <Mail size={15} className="text-slate-400" /> hello@appointease.demo
              </li>
              <li className="flex items-center gap-2">
                <Phone size={15} className="text-slate-400" /> +1 (555) 010-2025
              </li>
              <li className="flex items-center gap-2">
                <MapPin size={15} className="text-slate-400" /> 123 Demo Street, Sample City
              </li>
            </ul>
            <div className="mt-4 flex gap-4 text-sm">
              <button className="text-slate-500 transition-colors hover:text-brand-600">Privacy</button>
              <button className="text-slate-500 transition-colors hover:text-brand-600">Terms</button>
            </div>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-slate-200 pt-6 text-sm text-slate-500 sm:flex-row">
          <p>© {new Date().getFullYear()} AppointEase. Demo project.</p>
          <p>Built for the Webathon.</p>
        </div>
      </div>
    </footer>
  );
}
