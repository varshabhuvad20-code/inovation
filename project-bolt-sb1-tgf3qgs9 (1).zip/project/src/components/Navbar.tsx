import { CalendarCheck } from 'lucide-react';

type View = 'home' | 'book' | 'bookings' | 'about';

interface NavbarProps {
  view: View;
  onNavigate: (view: View) => void;
  mobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
}

const LINKS: { key: View; label: string }[] = [
  { key: 'home', label: 'Home' },
  { key: 'book', label: 'Book Appointment' },
  { key: 'bookings', label: 'My Bookings' },
  { key: 'about', label: 'About' },
];

export default function Navbar({ view, onNavigate, mobileOpen, setMobileOpen }: NavbarProps) {
  const go = (v: View) => {
    onNavigate(v);
    setMobileOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200/70 bg-white/80 backdrop-blur-lg">
      <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <button onClick={() => go('home')} className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-600 text-white shadow-lg shadow-brand-600/30">
            <CalendarCheck size={20} strokeWidth={2.5} />
          </span>
          <span className="font-display text-lg font-extrabold tracking-tight text-slate-900">
            Appoint<span className="text-brand-600">Ease</span>
          </span>
        </button>

        <div className="hidden items-center gap-1 md:flex">
          {LINKS.map((link) => (
            <button
              key={link.key}
              onClick={() => go(link.key)}
              className={`rounded-lg px-3.5 py-2 text-sm font-medium transition-colors ${
                view === link.key
                  ? 'bg-brand-50 text-brand-700'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              {link.label}
            </button>
          ))}
        </div>

        <div className="hidden md:block">
          <button onClick={() => go('book')} className="btn-primary">
            Book Now
          </button>
        </div>

        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="flex h-10 w-10 items-center justify-center rounded-lg text-slate-700 hover:bg-slate-100 md:hidden"
          aria-label="Toggle menu"
        >
          <div className="relative h-4 w-5">
            <span
              className={`absolute left-0 h-0.5 w-5 bg-current transition-all duration-300 ${
                mobileOpen ? 'top-2 rotate-45' : 'top-0'
              }`}
            />
            <span
              className={`absolute left-0 top-2 h-0.5 w-5 bg-current transition-all duration-300 ${
                mobileOpen ? 'opacity-0' : 'opacity-100'
              }`}
            />
            <span
              className={`absolute left-0 h-0.5 w-5 bg-current transition-all duration-300 ${
                mobileOpen ? 'top-2 -rotate-45' : 'top-4'
              }`}
            />
          </div>
        </button>
      </nav>

      {mobileOpen && (
        <div className="animate-fade-in border-t border-slate-200 bg-white md:hidden">
          <div className="space-y-1 px-4 py-3">
            {LINKS.map((link) => (
              <button
                key={link.key}
                onClick={() => go(link.key)}
                className={`block w-full rounded-lg px-3 py-2.5 text-left text-sm font-medium transition-colors ${
                  view === link.key
                    ? 'bg-brand-50 text-brand-700'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                {link.label}
              </button>
            ))}
            <button onClick={() => go('book')} className="btn-primary mt-2 w-full">
              Book Now
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
