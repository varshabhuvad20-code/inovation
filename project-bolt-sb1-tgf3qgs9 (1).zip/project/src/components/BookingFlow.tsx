import { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  ArrowLeft,
  ArrowRight,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  HeartHandshake,
  Smile,
  Stethoscope,
  UserRound,
} from 'lucide-react';
import type { Booking, ServiceId, TimeSlot } from '@/types';
import { PROVIDERS, SERVICES, getSlotsFor, serviceById } from '@/data';
import { useBookings } from '@/hooks/useBookings';
import { generateReference, newId } from '@/lib/storage';
import { formatDate, toISODate } from '@/lib/date';

interface BookingFlowProps {
  onComplete: (booking: Booking) => void;
  onCancel: () => void;
}

type Step = 1 | 2 | 3 | 4 | 5;

const ICONS: Record<string, typeof Stethoscope> = {
  Stethoscope,
  Smile,
  Activity,
  HeartHandshake,
  UserRound,
};

const STEPS = [
  { n: 1, label: 'Service' },
  { n: 2, label: 'Provider' },
  { n: 3, label: 'Date' },
  { n: 4, label: 'Time' },
  { n: 5, label: 'Details' },
];

export default function BookingFlow({ onComplete, onCancel }: BookingFlowProps) {
  const { bookings, addBooking } = useBookings();
  const [step, setStep] = useState<Step>(1);
  const [serviceId, setServiceId] = useState<ServiceId | null>(null);
  const [providerId, setProviderId] = useState<string | null>(null);
  const [dateISO, setDateISO] = useState<string>(toISODate(new Date()));
  const [viewMonth, setViewMonth] = useState<Date>(() => new Date());
  const [time, setTime] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  const providersForService = useMemo(
    () => (serviceId ? PROVIDERS.filter((p) => p.serviceIds.includes(serviceId)) : []),
    [serviceId],
  );

  const takenTimes = useMemo(
    () =>
      bookings
        .filter(
          (b) =>
            b.providerId === providerId &&
            b.date === dateISO &&
            b.status !== 'cancelled',
        )
        .map((b) => b.time),
    [bookings, providerId, dateISO],
  );

  const slots: TimeSlot[] = useMemo(
    () => (providerId ? getSlotsFor(dateISO, providerId, takenTimes) : []),
    [providerId, dateISO, takenTimes],
  );

  useEffect(() => {
    setTime(null);
  }, [dateISO, providerId, serviceId]);

  const canNext = (): boolean => {
    if (step === 1) return !!serviceId;
    if (step === 2) return !!providerId;
    if (step === 3) return !!dateISO;
    if (step === 4) return !!time;
    return true;
  };

  const next = () => {
    if (step === 1 && !serviceId) return;
    if (step === 2 && !providerId) return;
    if (step === 4 && !time) return;
    setStep((s) => (s < 5 ? ((s + 1) as Step) : s));
  };

  const back = () => setStep((s) => (s > 1 ? ((s - 1) as Step) : s));

  const validateDetails = (): boolean => {
    const e: Record<string, string> = {};
    if (!name.trim()) e.name = 'Please enter your name.';
    if (!email.trim()) e.email = 'Please enter your email.';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) e.email = 'Enter a valid email.';
    if (!phone.trim()) e.phone = 'Please enter your phone number.';
    else if (phone.replace(/\D/g, '').length < 7) e.phone = 'Enter a valid phone number.';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const confirm = () => {
    if (!validateDetails()) return;
    if (!serviceId || !providerId || !dateISO || !time) return;
    const svc = serviceById(serviceId)!;
    const provider = PROVIDERS.find((p) => p.id === providerId)!;
    setSubmitting(true);
    const booking: Booking = {
      id: newId(),
      reference: generateReference(),
      serviceId,
      serviceName: svc.name,
      providerId,
      providerName: provider.name,
      date: dateISO,
      time,
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      notes: notes.trim() || undefined,
      status: 'upcoming',
      createdAt: new Date().toISOString(),
    };
    setTimeout(() => {
      addBooking(booking);
      setSubmitting(false);
      onComplete(booking);
    }, 500);
  };

  const svc = serviceId ? serviceById(serviceId) : null;
  const provider = providerId ? PROVIDERS.find((p) => p.id === providerId) : null;

  return (
    <section id="book" className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
      <div className="mx-auto max-w-3xl text-center">
        <span className="section-label">Quick Booking</span>
        <h2 className="mt-4 font-display text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">
          Reserve your appointment
        </h2>
        <p className="mt-3 text-slate-600">
          Follow the steps below — it takes less than a minute.
        </p>
      </div>

      <div className="mx-auto mt-10 max-w-4xl">
        <StepIndicator current={step} />

        <div className="card mt-6 p-5 sm:p-8">
          {step === 1 && (
            <ServiceStep
              serviceId={serviceId}
              onSelect={(id) => {
                setServiceId(id);
                setProviderId(null);
              }}
            />
          )}
          {step === 2 && (
            <ProviderStep
              providers={providersForService}
              providerId={providerId}
              onSelect={setProviderId}
            />
          )}
          {step === 3 && (
            <DateStep
              viewMonth={viewMonth}
              setViewMonth={setViewMonth}
              dateISO={dateISO}
              onSelect={setDateISO}
            />
          )}
          {step === 4 && (
            <TimeStep
              slots={slots}
              time={time}
              onSelect={setTime}
              dateISO={dateISO}
              providerName={provider?.name}
            />
          )}
          {step === 5 && (
            <DetailsStep
              svc={svc?.name}
              providerName={provider?.name}
              dateISO={dateISO}
              time={time}
              name={name}
              email={email}
              phone={phone}
              notes={notes}
              errors={errors}
              onChange={{ setName, setEmail, setPhone, setNotes }}
            />
          )}

          <div className="mt-8 flex items-center justify-between gap-3 border-t border-slate-100 pt-6">
            <button
              onClick={step === 1 ? onCancel : back}
              className="btn-secondary"
            >
              <ArrowLeft size={16} /> {step === 1 ? 'Cancel' : 'Back'}
            </button>

            {step < 5 ? (
              <button onClick={next} disabled={!canNext()} className="btn-primary">
                Continue <ArrowRight size={16} />
              </button>
            ) : (
              <button
                onClick={confirm}
                disabled={submitting}
                className="btn-primary"
              >
                {submitting ? (
                  <>
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />
                    Confirming...
                  </>
                ) : (
                  <>
                    <CheckCircle2 size={18} /> Confirm Appointment
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

function StepIndicator({ current }: { current: Step }) {
  return (
    <div className="flex items-center justify-center">
      <div className="flex w-full max-w-2xl items-center">
        {STEPS.map((s, i) => (
          <div key={s.n} className="flex flex-1 items-center last:flex-none">
            <div className="flex flex-col items-center">
              <div
                className={`flex h-9 w-9 items-center justify-center rounded-full text-sm font-bold transition-all duration-300 ${
                  current > s.n
                    ? 'bg-brand-600 text-white shadow-md shadow-brand-600/30'
                    : current === s.n
                    ? 'bg-brand-600 text-white ring-4 ring-brand-100'
                    : 'bg-slate-100 text-slate-400'
                }`}
              >
                {current > s.n ? <Check size={16} /> : s.n}
              </div>
              <span
                className={`mt-1.5 hidden text-xs font-medium sm:block ${
                  current >= s.n ? 'text-slate-800' : 'text-slate-400'
                }`}
              >
                {s.label}
              </span>
            </div>
            {i < STEPS.length - 1 && (
              <div
                className={`mx-2 h-0.5 flex-1 rounded-full transition-colors duration-300 ${
                  current > s.n ? 'bg-brand-600' : 'bg-slate-200'
                }`}
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function StepHeader({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <div className="mb-6">
      <h3 className="font-display text-xl font-bold text-slate-900">{title}</h3>
      <p className="mt-1 text-sm text-slate-500">{subtitle}</p>
    </div>
  );
}

function ServiceStep({
  serviceId,
  onSelect,
}: {
  serviceId: ServiceId | null;
  onSelect: (id: ServiceId) => void;
}) {
  return (
    <div className="animate-fade-in">
      <StepHeader title="Select a service" subtitle="Choose the type of appointment you need." />
      <div className="grid gap-3 sm:grid-cols-2">
        {SERVICES.map((s) => {
          const Icon = ICONS[s.icon] ?? Stethoscope;
          const selected = serviceId === s.id;
          return (
            <button
              key={s.id}
              onClick={() => onSelect(s.id)}
              className={`group flex items-start gap-4 rounded-xl border p-4 text-left transition-all duration-200 ${
                selected
                  ? 'border-brand-600 bg-brand-50/60 ring-2 ring-brand-100'
                  : 'border-slate-200 hover:border-brand-300 hover:bg-slate-50'
              }`}
            >
              <span
                className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl transition-colors ${
                  selected
                    ? 'bg-brand-600 text-white'
                    : 'bg-slate-100 text-slate-600 group-hover:bg-brand-100 group-hover:text-brand-600'
                }`}
              >
                <Icon size={20} />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-semibold text-slate-900">{s.name}</p>
                  {selected && <Check size={18} className="text-brand-600" />}
                </div>
                <p className="mt-0.5 text-sm text-slate-500">{s.description}</p>
                <p className="mt-2 text-xs font-medium text-slate-400">{s.durationMinutes} min</p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function ProviderStep({
  providers,
  providerId,
  onSelect,
}: {
  providers: typeof PROVIDERS;
  providerId: string | null;
  onSelect: (id: string) => void;
}) {
  return (
    <div className="animate-fade-in">
      <StepHeader title="Select a provider" subtitle="Pick who you'd like to see for this service." />
      {providers.length === 0 ? (
        <p className="rounded-lg bg-amber-50 p-4 text-sm text-amber-700">
          Please select a service first.
        </p>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {providers.map((p) => {
            const selected = providerId === p.id;
            return (
              <button
                key={p.id}
                onClick={() => onSelect(p.id)}
                className={`group flex items-center gap-4 rounded-xl border p-4 text-left transition-all duration-200 ${
                  selected
                    ? 'border-brand-600 bg-brand-50/60 ring-2 ring-brand-100'
                    : 'border-slate-200 hover:border-brand-300 hover:bg-slate-50'
                }`}
              >
                <span
                  className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gradient-to-br ${p.accent} font-display text-sm font-bold text-white shadow-md`}
                >
                  {p.initials}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="truncate font-semibold text-slate-900">{p.name}</p>
                    {selected && <Check size={18} className="shrink-0 text-brand-600" />}
                  </div>
                  <p className="mt-0.5 text-sm text-slate-500">{p.role}</p>
                  <div className="mt-2 flex items-center gap-2">
                    <span
                      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ${
                        p.availableToday
                          ? 'bg-emerald-50 text-emerald-700'
                          : 'bg-slate-100 text-slate-500'
                      }`}
                    >
                      <span
                        className={`h-1.5 w-1.5 rounded-full ${
                          p.availableToday ? 'bg-emerald-500' : 'bg-slate-400'
                        }`}
                      />
                      {p.availableToday ? 'Available today' : 'Limited today'}
                    </span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

function DateStep({
  viewMonth,
  setViewMonth,
  dateISO,
  onSelect,
}: {
  viewMonth: Date;
  setViewMonth: (d: Date) => void;
  dateISO: string;
  onSelect: (iso: string) => void;
}) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const year = viewMonth.getFullYear();
  const month = viewMonth.getMonth();
  const firstDay = new Date(year, month, 1);
  const startOffset = firstDay.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const cells: (Date | null)[] = [];
  for (let i = 0; i < startOffset; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, month, d));

  const monthLabel = viewMonth.toLocaleDateString('en-US', {
    month: 'long',
    year: 'numeric',
  });

  const shiftMonth = (delta: number) => {
    setViewMonth(new Date(year, month + delta, 1));
  };

  return (
    <div className="animate-fade-in">
      <StepHeader title="Select a date" subtitle="Pick the day that works best for you." />
      <div className="mx-auto max-w-sm">
        <div className="mb-4 flex items-center justify-between">
          <button
            onClick={() => shiftMonth(-1)}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-600 transition-colors hover:bg-slate-50"
            aria-label="Previous month"
          >
            <ChevronLeft size={18} />
          </button>
          <p className="font-display text-base font-bold text-slate-900">{monthLabel}</p>
          <button
            onClick={() => shiftMonth(1)}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-600 transition-colors hover:bg-slate-50"
            aria-label="Next month"
          >
            <ChevronRight size={18} />
          </button>
        </div>

        <div className="grid grid-cols-7 gap-1 text-center text-xs font-semibold text-slate-400">
          {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map((d) => (
            <div key={d} className="py-1">
              {d}
            </div>
          ))}
        </div>
        <div className="mt-1 grid grid-cols-7 gap-1">
          {cells.map((d, i) => {
            if (!d) return <div key={i} />;
            const iso = toISODate(d);
            const isPast = d < today;
            const isSelected = iso === dateISO;
            const isToday = iso === toISODate(today);
            return (
              <button
                key={i}
                disabled={isPast}
                onClick={() => onSelect(iso)}
                className={`relative aspect-square rounded-lg text-sm font-medium transition-all duration-150 ${
                  isSelected
                    ? 'bg-brand-600 text-white shadow-md shadow-brand-600/30'
                    : isPast
                    ? 'cursor-not-allowed text-slate-300'
                    : 'text-slate-700 hover:bg-brand-50 hover:text-brand-700'
                }`}
              >
                {d.getDate()}
                {isToday && !isSelected && (
                  <span className="absolute bottom-1 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-brand-500" />
                )}
              </button>
            );
          })}
        </div>
        <div className="mt-4 flex items-center gap-2 rounded-lg bg-brand-50 px-3 py-2.5 text-sm text-brand-700">
          <CalendarDays size={16} />
          {dateISO ? (
            <span className="font-medium">{formatDate(dateISO)}</span>
          ) : (
            <span>Select a date to continue</span>
          )}
        </div>
      </div>
    </div>
  );
}

function TimeStep({
  slots,
  time,
  onSelect,
  dateISO,
  providerName,
}: {
  slots: TimeSlot[];
  time: string | null;
  onSelect: (t: string) => void;
  dateISO: string;
  providerName?: string;
}) {
  const morning = slots.filter((s) => !s.time.includes('PM'));
  const afternoon = slots.filter((s) => s.time.includes('PM'));

  const renderGroup = (label: string, list: TimeSlot[]) => (
    <div>
      <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">{label}</p>
      <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
        {list.map((s) => {
          const selected = time === s.time;
          const unavailable = s.state === 'unavailable';
          return (
            <button
              key={s.time}
              disabled={unavailable}
              onClick={() => onSelect(s.time)}
              className={`rounded-lg px-2 py-2.5 text-sm font-semibold transition-all duration-150 ${
                selected
                  ? 'bg-brand-600 text-white shadow-md shadow-brand-600/30'
                  : unavailable
                  ? 'cursor-not-allowed bg-slate-100 text-slate-300 line-through'
                  : 'bg-white text-slate-700 ring-1 ring-slate-200 hover:bg-brand-50 hover:text-brand-700 hover:ring-brand-300 active:scale-95'
              }`}
            >
              {s.time}
            </button>
          );
        })}
      </div>
    </div>
  );

  return (
    <div className="animate-fade-in">
      <StepHeader
        title="Select a time"
        subtitle={providerName ? `Available slots with ${providerName} on ${formatDate(dateISO)}.` : 'Available slots for the selected date.'}
      />
      <div className="space-y-5">
        {renderGroup('Morning', morning)}
        {renderGroup('Afternoon', afternoon)}
      </div>
      <div className="mt-5 flex flex-wrap items-center gap-4 text-xs text-slate-500">
        <span className="flex items-center gap-1.5">
          <span className="h-3 w-3 rounded bg-white ring-1 ring-slate-200" /> Available
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-3 w-3 rounded bg-brand-600" /> Selected
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-3 w-3 rounded bg-slate-100" /> Unavailable
        </span>
      </div>
    </div>
  );
}

function DetailsStep({
  svc,
  providerName,
  dateISO,
  time,
  name,
  email,
  phone,
  notes,
  errors,
  onChange,
}: {
  svc?: string;
  providerName?: string;
  dateISO: string;
  time: string | null;
  name: string;
  email: string;
  phone: string;
  notes: string;
  errors: Record<string, string>;
  onChange: {
    setName: (v: string) => void;
    setEmail: (v: string) => void;
    setPhone: (v: string) => void;
    setNotes: (v: string) => void;
  };
}) {
  const inputCls = (err?: string) =>
    `w-full rounded-xl border bg-white px-4 py-2.5 text-sm text-slate-900 placeholder-slate-400 outline-none transition-all focus:ring-4 ${
      err
        ? 'border-red-300 focus:border-red-400 focus:ring-red-100'
        : 'border-slate-200 focus:border-brand-500 focus:ring-brand-100'
    }`;

  return (
    <div className="animate-fade-in">
      <StepHeader title="Your details" subtitle="Confirm a summary and enter your contact info." />

      <div className="mb-6 rounded-xl border border-slate-200 bg-slate-50/60 p-4">
        <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
          Appointment summary
        </p>
        <dl className="grid gap-3 sm:grid-cols-2">
          <SummaryRow label="Service" value={svc} />
          <SummaryRow label="Provider" value={providerName} />
          <SummaryRow label="Date" value={formatDate(dateISO)} />
          <SummaryRow label="Time" value={time ?? undefined} />
        </dl>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Full name" error={errors.name} required>
          <input
            type="text"
            value={name}
            onChange={(e) => onChange.setName(e.target.value)}
            placeholder="Jane Doe"
            className={inputCls(errors.name)}
          />
        </Field>
        <Field label="Email" error={errors.email} required>
          <input
            type="email"
            value={email}
            onChange={(e) => onChange.setEmail(e.target.value)}
            placeholder="jane@example.com"
            className={inputCls(errors.email)}
          />
        </Field>
        <Field label="Phone" error={errors.phone} required>
          <input
            type="tel"
            value={phone}
            onChange={(e) => onChange.setPhone(e.target.value)}
            placeholder="+1 555 123 4567"
            className={inputCls(errors.phone)}
          />
        </Field>
        <Field label="Notes (optional)">
          <input
            type="text"
            value={notes}
            onChange={(e) => onChange.setNotes(e.target.value)}
            placeholder="Anything we should know?"
            className={inputCls()}
          />
        </Field>
      </div>
    </div>
  );
}

function SummaryRow({ label, value }: { label: string; value?: string }) {
  return (
    <div>
      <dt className="text-xs font-medium text-slate-400">{label}</dt>
      <dd className="mt-0.5 text-sm font-semibold text-slate-800">{value ?? '—'}</dd>
    </div>
  );
}

function Field({
  label,
  error,
  required,
  children,
}: {
  label: string;
  error?: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-slate-700">
        {label}
        {required && <span className="text-brand-600"> *</span>}
      </span>
      {children}
      {error && <span className="mt-1 block text-xs font-medium text-red-500">{error}</span>}
    </label>
  );
}
