import { useMemo, useState } from 'react';
import {
  CalendarDays,
  CalendarX2,
  Clock,
  Eye,
  MapPin,
  Phone,
  Mail,
  RefreshCw,
  Search,
  Tag,
  User,
  X,
  XCircle,
} from 'lucide-react';
import type { Booking, BookingStatus, TimeSlot } from '@/types';
import { useBookings } from '@/hooks/useBookings';
import { PROVIDERS, getSlotsFor } from '@/data';
import { formatDate, toISODate } from '@/lib/date';
import ConfirmDialog from './ConfirmDialog';

interface MyBookingsProps {
  onBookNew: () => void;
}

type Filter = 'all' | 'upcoming' | 'cancelled' | 'completed';

const STATUS_STYLES: Record<BookingStatus, string> = {
  upcoming: 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200',
  completed: 'bg-slate-100 text-slate-600 ring-1 ring-slate-200',
  cancelled: 'bg-red-50 text-red-600 ring-1 ring-red-200',
};

export default function MyBookings({ onBookNew }: MyBookingsProps) {
  const { bookings, updateBooking, removeBooking } = useBookings();
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  const [cancelTarget, setCancelTarget] = useState<Booking | null>(null);
  const [rescheduleTarget, setRescheduleTarget] = useState<Booking | null>(null);
  const [detailsTarget, setDetailsTarget] = useState<Booking | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return bookings
      .filter((b) => (filter === 'all' ? true : b.status === filter))
      .filter((b) => {
        if (!q) return true;
        return (
          b.reference.toLowerCase().includes(q) ||
          b.serviceName.toLowerCase().includes(q) ||
          b.providerName.toLowerCase().includes(q) ||
          b.name.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => (a.date + a.time < b.date + b.time ? 1 : -1));
  }, [bookings, query, filter]);

  const counts = useMemo(
    () => ({
      all: bookings.length,
      upcoming: bookings.filter((b) => b.status === 'upcoming').length,
      completed: bookings.filter((b) => b.status === 'completed').length,
      cancelled: bookings.filter((b) => b.status === 'cancelled').length,
    }),
    [bookings],
  );

  const confirmCancel = () => {
    if (!cancelTarget) return;
    updateBooking(cancelTarget.id, { status: 'cancelled' });
    setCancelTarget(null);
  };

  return (
    <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <span className="section-label">My Bookings</span>
          <h2 className="mt-3 font-display text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">
            Manage your appointments
          </h2>
          <p className="mt-2 text-slate-600">View, reschedule, or cancel your bookings.</p>
        </div>
        <button onClick={onBookNew} className="btn-primary shrink-0">
          <CalendarDays size={18} /> New Booking
        </button>
      </div>

      <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search size={18} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by reference, service, or provider..."
            className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-11 pr-4 text-sm text-slate-900 placeholder-slate-400 outline-none transition-all focus:border-brand-500 focus:ring-4 focus:ring-brand-100"
          />
        </div>
        <div className="flex flex-wrap gap-1.5 rounded-xl border border-slate-200 bg-white p-1">
          {(['all', 'upcoming', 'completed', 'cancelled'] as Filter[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`rounded-lg px-3 py-1.5 text-sm font-medium capitalize transition-colors ${
                filter === f ? 'bg-brand-600 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {f} <span className="opacity-60">({counts[f]})</span>
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <EmptyState hasBookings={bookings.length > 0} onBookNew={onBookNew} />
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((b) => (
            <BookingCard
              key={b.id}
              booking={b}
              onView={() => setDetailsTarget(b)}
              onReschedule={() => setRescheduleTarget(b)}
              onCancel={() => setCancelTarget(b)}
            />
          ))}
        </div>
      )}

      <ConfirmDialog
        open={!!cancelTarget}
        title="Cancel this appointment?"
        message={`Booking ${cancelTarget?.reference} with ${cancelTarget?.providerName} on ${
          cancelTarget ? formatDate(cancelTarget.date) : ''
        } at ${cancelTarget?.time} will be cancelled.`}
        confirmLabel="Yes, cancel"
        destructive
        onConfirm={confirmCancel}
        onCancel={() => setCancelTarget(null)}
      />

      {rescheduleTarget && (
        <RescheduleModal
          booking={rescheduleTarget}
          onClose={() => setRescheduleTarget(null)}
          onConfirm={(date, time) => {
            updateBooking(rescheduleTarget.id, { date, time, status: 'upcoming' });
            setRescheduleTarget(null);
          }}
        />
      )}

      {detailsTarget && (
        <DetailsDrawer booking={detailsTarget} onClose={() => setDetailsTarget(null)} />
      )}
    </section>
  );
}

function BookingCard({
  booking,
  onView,
  onReschedule,
  onCancel,
}: {
  booking: Booking;
  onView: () => void;
  onReschedule: () => void;
  onCancel: () => void;
}) {
  const isCancelled = booking.status === 'cancelled';
  return (
    <div
      className={`card group flex flex-col p-5 transition-all duration-200 hover:shadow-md ${
        isCancelled ? 'opacity-75' : ''
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="rounded-md bg-slate-100 px-2 py-1 font-mono text-xs font-semibold text-slate-600">
            {booking.reference}
          </span>
        </div>
        <span
          className={`rounded-full px-2.5 py-1 text-xs font-semibold capitalize ${STATUS_STYLES[booking.status]}`}
        >
          {booking.status}
        </span>
      </div>

      <h3 className="mt-3 font-display text-lg font-bold text-slate-900">{booking.serviceName}</h3>
      <p className="mt-0.5 text-sm text-slate-500">{booking.providerName}</p>

      <div className="mt-4 space-y-2 text-sm">
        <div className="flex items-center gap-2 text-slate-600">
          <CalendarDays size={15} className="text-slate-400" />
          {formatDate(booking.date)}
        </div>
        <div className="flex items-center gap-2 text-slate-600">
          <Clock size={15} className="text-slate-400" />
          {booking.time}
        </div>
      </div>

      <div className="mt-5 flex items-center gap-2 border-t border-slate-100 pt-4">
        <button onClick={onView} className="btn-ghost flex-1">
          <Eye size={15} /> Details
        </button>
        {!isCancelled && (
          <>
            <button onClick={onReschedule} className="btn-ghost flex-1">
              <RefreshCw size={15} /> Reschedule
            </button>
            <button
              onClick={onCancel}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium text-red-600 transition-colors hover:bg-red-50"
            >
              <XCircle size={15} /> Cancel
            </button>
          </>
        )}
      </div>
    </div>
  );
}

function EmptyState({ hasBookings, onBookNew }: { hasBookings: boolean; onBookNew: () => void }) {
  return (
    <div className="mt-6 flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-16 text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 text-slate-400">
        {hasBookings ? <Search size={28} /> : <CalendarX2 size={28} />}
      </div>
      <h3 className="mt-4 font-display text-lg font-bold text-slate-900">
        {hasBookings ? 'No matching bookings' : 'No bookings yet'}
      </h3>
      <p className="mt-1 max-w-sm text-sm text-slate-500">
        {hasBookings
          ? 'Try adjusting your search or filter to find what you’re looking for.'
          : 'Book your first appointment to see it here.'}
      </p>
      {!hasBookings && (
        <button onClick={onBookNew} className="btn-primary mt-5">
          <CalendarDays size={18} /> Book an Appointment
        </button>
      )}
    </div>
  );
}

function RescheduleModal({
  booking,
  onClose,
  onConfirm,
}: {
  booking: Booking;
  onClose: () => void;
  onConfirm: (date: string, time: string) => void;
}) {
  const { bookings } = useBookings();
  const [dateISO, setDateISO] = useState(toISODate(new Date()));
  const [viewMonth, setViewMonth] = useState(() => new Date());
  const [time, setTime] = useState<string | null>(null);
  const [error, setError] = useState('');

  const takenTimes = bookings
    .filter(
      (b) =>
        b.id !== booking.id &&
        b.providerId === booking.providerId &&
        b.date === dateISO &&
        b.status !== 'cancelled',
    )
    .map((b) => b.time);

  const slots: TimeSlot[] = getSlotsFor(dateISO, booking.providerId, takenTimes);

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const year = viewMonth.getFullYear();
  const month = viewMonth.getMonth();
  const startOffset = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells: (Date | null)[] = [];
  for (let i = 0; i < startOffset; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, month, d));

  const confirm = () => {
    if (!time) {
      setError('Please select a new time slot.');
      return;
    }
    onConfirm(dateISO, time);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative w-full max-w-lg max-h-[90vh] animate-scale-in overflow-y-auto rounded-2xl bg-white shadow-2xl">
        <div className="sticky top-0 flex items-center justify-between border-b border-slate-100 bg-white px-5 py-4">
          <div>
            <h3 className="font-display text-lg font-bold text-slate-900">Reschedule</h3>
            <p className="text-xs text-slate-500">{booking.reference} · {booking.serviceName}</p>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100"
          >
            <X size={18} />
          </button>
        </div>

        <div className="p-5">
          <p className="mb-3 text-sm text-slate-600">
            Currently booked for <strong>{formatDate(booking.date)}</strong> at <strong>{booking.time}</strong>. Choose a new date and time below.
          </p>

          <div className="mx-auto max-w-sm">
            <div className="mb-3 flex items-center justify-between">
              <button
                onClick={() => setViewMonth(new Date(year, month - 1, 1))}
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50"
              >
                ‹
              </button>
              <p className="font-display text-sm font-bold text-slate-900">
                {viewMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
              </p>
              <button
                onClick={() => setViewMonth(new Date(year, month + 1, 1))}
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50"
              >
                ›
              </button>
            </div>
            <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-semibold text-slate-400">
              {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map((d) => (
                <div key={d} className="py-1">{d}</div>
              ))}
            </div>
            <div className="mt-1 grid grid-cols-7 gap-1">
              {cells.map((d, i) => {
                if (!d) return <div key={i} />;
                const iso = toISODate(d);
                const isPast = d < today;
                const isSelected = iso === dateISO;
                return (
                  <button
                    key={i}
                    disabled={isPast}
                    onClick={() => { setDateISO(iso); setTime(null); setError(''); }}
                    className={`aspect-square rounded-lg text-xs font-medium transition-all ${
                      isSelected
                        ? 'bg-brand-600 text-white'
                        : isPast
                        ? 'cursor-not-allowed text-slate-300'
                        : 'text-slate-700 hover:bg-brand-50 hover:text-brand-700'
                    }`}
                  >
                    {d.getDate()}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="mt-5">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">Available times</p>
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
              {slots.map((s) => (
                <button
                  key={s.time}
                  disabled={s.state === 'unavailable'}
                  onClick={() => { setTime(s.time); setError(''); }}
                  className={`rounded-lg px-2 py-2 text-xs font-semibold transition-all ${
                    time === s.time
                      ? 'bg-brand-600 text-white'
                      : s.state === 'unavailable'
                      ? 'cursor-not-allowed bg-slate-100 text-slate-300 line-through'
                      : 'bg-white text-slate-700 ring-1 ring-slate-200 hover:bg-brand-50 hover:text-brand-700'
                  }`}
                >
                  {s.time}
                </button>
              ))}
            </div>
            {error && <p className="mt-2 text-xs font-medium text-red-500">{error}</p>}
          </div>

          <div className="mt-6 flex gap-3">
            <button onClick={onClose} className="btn-secondary flex-1">Cancel</button>
            <button onClick={confirm} className="btn-primary flex-1">
              <RefreshCw size={16} /> Confirm Reschedule
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function DetailsDrawer({ booking, onClose }: { booking: Booking; onClose: () => void }) {
  const provider = PROVIDERS.find((p) => p.id === booking.providerId);
  return (
    <div className="fixed inset-0 z-[100] flex justify-end">
      <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative h-full w-full max-w-md animate-fade-in overflow-y-auto bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
          <h3 className="font-display text-lg font-bold text-slate-900">Appointment details</h3>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100"
          >
            <X size={18} />
          </button>
        </div>
        <div className="p-5">
          <div className="flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3">
            <span className="text-xs font-medium text-slate-400">Reference</span>
            <span className="font-mono text-sm font-bold text-brand-700">{booking.reference}</span>
          </div>
          <span
            className={`mt-4 inline-block rounded-full px-2.5 py-1 text-xs font-semibold capitalize ${STATUS_STYLES[booking.status]}`}
          >
            {booking.status}
          </span>

          <div className="mt-5 space-y-4">
            <Detail icon={Tag} label="Service" value={booking.serviceName} />
            <Detail icon={User} label="Provider" value={booking.providerName} />
            {provider && <Detail icon={MapPin} label="Specialization" value={provider.specialization} />}
            <Detail icon={CalendarDays} label="Date" value={formatDate(booking.date)} />
            <Detail icon={Clock} label="Time" value={booking.time} />
            <div className="border-t border-slate-100 pt-4" />
            <Detail icon={User} label="Name" value={booking.name} />
            <Detail icon={Mail} label="Email" value={booking.email} />
            <Detail icon={Phone} label="Phone" value={booking.phone} />
            {booking.notes && <Detail icon={Tag} label="Notes" value={booking.notes} />}
          </div>
        </div>
      </div>
    </div>
  );
}

function Detail({ icon: Icon, label, value }: { icon: typeof User; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3">
      <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
        <Icon size={15} />
      </span>
      <div className="min-w-0">
        <p className="text-xs font-medium text-slate-400">{label}</p>
        <p className="text-sm font-semibold text-slate-800 break-words">{value}</p>
      </div>
    </div>
  );
}
