import { CalendarCheck, CalendarPlus, CheckCircle2, ListChecks, X } from 'lucide-react';
import type { Booking } from '@/types';
import { formatDate } from '@/lib/date';

interface SuccessModalProps {
  booking: Booking;
  onView: () => void;
  onBookAnother: () => void;
  onClose: () => void;
}

export default function SuccessModal({ booking, onView, onBookAnother, onClose }: SuccessModalProps) {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative w-full max-w-md animate-scale-in overflow-hidden rounded-2xl bg-white shadow-2xl">
        <div className="relative bg-gradient-to-br from-brand-600 to-brand-700 px-6 pb-8 pt-7 text-center">
          <button
            onClick={onClose}
            className="absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-lg text-white/80 transition-colors hover:bg-white/10 hover:text-white"
            aria-label="Close"
          >
            <X size={18} />
          </button>
          <div className="mx-auto flex h-16 w-16 animate-scale-in items-center justify-center rounded-full bg-white/15 ring-4 ring-white/20">
            <CheckCircle2 size={36} className="text-white" />
          </div>
          <h3 className="mt-4 font-display text-xl font-bold text-white">Appointment Confirmed!</h3>
          <p className="mt-1 text-sm text-brand-100">
            Your booking has been saved. A reminder is on its way.
          </p>
        </div>

        <div className="px-6 py-5">
          <div className="mb-4 flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3">
            <span className="text-xs font-medium text-slate-400">Reference ID</span>
            <span className="font-display text-base font-bold text-brand-700">{booking.reference}</span>
          </div>

          <dl className="space-y-2.5 text-sm">
            <Row label="Service" value={booking.serviceName} />
            <Row label="Provider" value={booking.providerName} />
            <Row label="Date" value={formatDate(booking.date)} />
            <Row label="Time" value={booking.time} />
            <Row label="Name" value={booking.name} />
          </dl>

          <div className="mt-6 flex flex-col gap-2.5 sm:flex-row">
            <button onClick={onView} className="btn-secondary flex-1">
              <ListChecks size={16} /> View My Booking
            </button>
            <button onClick={onBookAnother} className="btn-primary flex-1">
              <CalendarPlus size={16} /> Book Another
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <dt className="text-slate-400">{label}</dt>
      <dd className="text-right font-semibold text-slate-800">{value}</dd>
    </div>
  );
}

export function CalendarCheckBadge() {
  return <CalendarCheck />;
}
