import { CalendarCheck, Clock, ShieldCheck, Users } from 'lucide-react';

interface AboutProps {
  onBook: () => void;
}

const POINTS = [
  {
    icon: Clock,
    title: 'Fast & focused',
    desc: 'A booking flow designed to take seconds, not minutes — no clutter, no detours.',
  },
  {
    icon: ShieldCheck,
    title: 'Clear & reliable',
    desc: 'Real-time slot availability and duplicate-prevention keep your schedule accurate.',
  },
  {
    icon: Users,
    title: 'People-first',
    desc: 'General enough for any appointment-based service, with provider choice built in.',
  },
];

export default function About({ onBook }: AboutProps) {
  return (
    <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
      <div className="grid items-center gap-12 lg:grid-cols-2">
        <div className="animate-fade-up">
          <span className="section-label">
            <CalendarCheck size={13} /> About
          </span>
          <h2 className="mt-4 font-display text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">
            A booking experience that respects your time
          </h2>
          <p className="mt-4 text-lg leading-relaxed text-slate-600">
            AppointEase is a polished prototype of an online appointment-booking system. It demonstrates
            a complete scheduling journey — from choosing a service to managing confirmed bookings — in a
            clean, trustworthy interface.
          </p>
          <p className="mt-4 text-slate-600">
            All provider names, time slots, and references are fictional and generated for demonstration.
          </p>
          <button onClick={onBook} className="btn-primary mt-6">
            <CalendarCheck size={18} /> Try the booking flow
          </button>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          {POINTS.map((p, i) => (
            <div
              key={p.title}
              className={`animate-fade-up rounded-2xl border border-slate-200 bg-white p-6 ${
                i === 2 ? 'sm:col-span-2' : ''
              }`}
              style={{ animationDelay: `${i * 100}ms` }}
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-50 text-brand-600">
                <p.icon size={20} />
              </span>
              <h3 className="mt-4 font-display text-base font-bold text-slate-900">{p.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-slate-600">{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
