import { CalendarCheck, MousePointerClick, ClipboardList } from 'lucide-react';

const STEPS = [
  {
    n: '01',
    title: 'Choose a service',
    desc: 'Browse available services and pick the one that fits your needs.',
    icon: MousePointerClick,
  },
  {
    n: '02',
    title: 'Pick a date & time',
    desc: 'Select a convenient day and reserve from real-time available slots.',
    icon: CalendarCheck,
  },
  {
    n: '03',
    title: 'Confirm your appointment',
    desc: 'Enter your details and confirm — your booking is saved instantly.',
    icon: ClipboardList,
  },
];

export default function HowItWorks() {
  return (
    <section className="bg-white py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="section-label">How it works</span>
          <h2 className="mt-4 font-display text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">
            Book in three simple steps
          </h2>
          <p className="mt-3 text-slate-600">
            No phone calls, no waiting on hold — just a clear, quick booking process.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {STEPS.map((s, i) => (
            <div
              key={s.n}
              className="group relative animate-fade-up rounded-2xl border border-slate-200 bg-white p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg [animation-delay:${i * 100}ms]"
              style={{ animationDelay: `${i * 100}ms` }}
            >
              <span className="absolute right-5 top-5 font-display text-5xl font-extrabold text-slate-100 transition-colors group-hover:text-brand-100">
                {s.n}
              </span>
              <div className="relative">
                <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-50 text-brand-600 transition-transform duration-300 group-hover:scale-110">
                  <s.icon size={22} />
                </span>
                <h3 className="mt-4 font-display text-lg font-bold text-slate-900">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-600">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
