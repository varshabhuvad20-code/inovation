import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

const FAQS = [
  {
    q: 'How do I book an appointment?',
    a: 'Click "Book Now" or "Book an Appointment", then follow the steps: choose a service, select a provider, pick a date, choose an available time slot, enter your details, and confirm. You’ll get a reference ID once it’s saved.',
  },
  {
    q: 'Can I reschedule?',
    a: 'Yes. Go to "My Bookings", find the appointment, and click "Reschedule". Pick a new date and an available time, then confirm. The booking updates instantly.',
  },
  {
    q: 'Can I cancel an appointment?',
    a: 'Yes. In "My Bookings", click "Cancel" on any upcoming appointment. You’ll see a confirmation dialog before the appointment is cancelled.',
  },
  {
    q: 'How do I see my bookings?',
    a: 'Open "My Bookings" from the navigation. You can search by reference, service, or provider, and filter by upcoming, completed, or cancelled status.',
  },
  {
    q: 'What happens after confirmation?',
    a: 'You’ll see a success screen with your appointment reference and a summary of the details. The booking is saved and appears in "My Bookings" right away.',
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section className="bg-white py-16 sm:py-20">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <span className="section-label">FAQ</span>
          <h2 className="mt-4 font-display text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">
            Frequently asked questions
          </h2>
        </div>

        <div className="mt-10 space-y-3">
          {FAQS.map((f, i) => {
            const isOpen = open === i;
            return (
              <div
                key={i}
                className={`overflow-hidden rounded-xl border transition-colors ${
                  isOpen ? 'border-brand-200 bg-brand-50/30' : 'border-slate-200 bg-white'
                }`}
              >
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
                >
                  <span className="font-display text-sm font-bold text-slate-900 sm:text-base">
                    {f.q}
                  </span>
                  <ChevronDown
                    size={20}
                    className={`shrink-0 text-slate-400 transition-transform duration-300 ${
                      isOpen ? 'rotate-180 text-brand-600' : ''
                    }`}
                  />
                </button>
                <div
                  className={`grid transition-all duration-300 ease-out ${
                    isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
                  }`}
                >
                  <div className="overflow-hidden">
                    <p className="px-5 pb-4 text-sm leading-relaxed text-slate-600">{f.a}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
