import { CalendarCheck, Clock, Search, ShieldCheck, Sparkles } from 'lucide-react';

interface HeroProps {
  onBook: () => void;
  onMyBookings: () => void;
}

export default function Hero({ onBook, onMyBookings }: HeroProps) {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-brand-50/60 via-white to-white">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -right-24 -top-24 h-96 w-96 rounded-full bg-brand-200/30 blur-3xl" />
        <div className="absolute -left-32 top-40 h-80 w-80 rounded-full bg-sky-200/20 blur-3xl" />
      </div>

      <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:gap-8 lg:px-8 lg:py-24">
        <div className="animate-fade-up">
          <span className="section-label">
            <Sparkles size={13} /> Simple online scheduling
          </span>
          <h1 className="mt-5 font-display text-4xl font-extrabold leading-[1.1] tracking-tight text-slate-900 sm:text-5xl lg:text-6xl">
            Book Your Appointment.
            <span className="block text-brand-600">Your Time Matters.</span>
          </h1>
          <p className="mt-5 max-w-xl text-lg leading-relaxed text-slate-600">
            Find a convenient time, reserve your appointment in a few simple steps, and manage your
            bookings from one place.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <button onClick={onBook} className="btn-primary px-6 py-3.5 text-base">
              <CalendarCheck size={18} /> Book an Appointment
            </button>
            <button onClick={onMyBookings} className="btn-secondary px-6 py-3.5 text-base">
              View My Bookings
            </button>
          </div>

          <div className="mt-10 flex flex-wrap gap-x-6 gap-y-3">
            {[
              { icon: ShieldCheck, text: 'Simple booking' },
              { icon: Clock, text: 'Real-time slot selection' },
              { icon: Search, text: 'Easy management' },
            ].map(({ icon: Icon, text }) => (
              <div key={text} className="flex items-center gap-2 text-sm font-medium text-slate-600">
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-brand-50 text-brand-600">
                  <Icon size={15} />
                </span>
                {text}
              </div>
            ))}
          </div>
        </div>

        <div className="animate-fade-up [animation-delay:150ms]">
          <HeroVisual />
        </div>
      </div>
    </section>
  );
}

function HeroVisual() {
  return (
    <div className="relative mx-auto max-w-md lg:max-w-none">
      <div className="card overflow-hidden p-6 shadow-xl shadow-brand-900/5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Appointment
            </p>
            <p className="font-display text-lg font-bold text-slate-900">Dr. Amara Okafor</p>
          </div>
          <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
            Confirmed
          </span>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3">
          <div className="rounded-xl bg-slate-50 p-4">
            <p className="text-xs font-medium text-slate-400">Service</p>
            <p className="mt-1 text-sm font-semibold text-slate-800">General Consultation</p>
          </div>
          <div className="rounded-xl bg-slate-50 p-4">
            <p className="text-xs font-medium text-slate-400">Duration</p>
            <p className="mt-1 text-sm font-semibold text-slate-800">30 minutes</p>
          </div>
        </div>

        <div className="mt-4 rounded-xl border border-brand-100 bg-brand-50/50 p-4">
          <p className="text-xs font-medium text-brand-700/70">Date & Time</p>
          <p className="mt-1 font-display text-base font-bold text-brand-700">
            Friday, Oct 17 · 10:00 AM
          </p>
        </div>

        <div className="mt-4 grid grid-cols-4 gap-2">
          {['09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '02:00', '02:30'].map((s, i) => (
            <div
              key={s}
              className={`rounded-lg px-2 py-2 text-center text-xs font-semibold transition-all ${
                i === 2
                  ? 'bg-brand-600 text-white shadow-md shadow-brand-600/30'
                  : i % 3 === 1
                  ? 'bg-slate-100 text-slate-300 line-through'
                  : 'bg-white text-slate-500 ring-1 ring-slate-200'
              }`}
            >
              {s}
            </div>
          ))}
        </div>
      </div>

      <div className="absolute -bottom-5 -left-5 hidden rounded-2xl border border-slate-200 bg-white p-4 shadow-lg sm:block">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
            <CalendarCheck size={20} />
          </span>
          <div>
            <p className="text-xs font-medium text-slate-400">Reference</p>
            <p className="font-display text-sm font-bold text-slate-900">AE-OCT-1042</p>
          </div>
        </div>
      </div>
    </div>
  );
}
