import { CalendarRange, Clock3, FileText, LayoutGrid, Layers } from 'lucide-react';

const BENEFITS = [
  {
    icon: CalendarRange,
    title: 'Easy scheduling',
    desc: 'A guided, step-by-step flow that takes you from service to confirmation in under a minute.',
  },
  {
    icon: Clock3,
    title: 'Flexible time selection',
    desc: 'Pick from morning or afternoon slots that update in real time as bookings fill up.',
  },
  {
    icon: FileText,
    title: 'Clear appointment details',
    desc: 'Every booking shows its reference, provider, date, time, and status at a glance.',
  },
  {
    icon: LayoutGrid,
    title: 'Simple booking management',
    desc: 'View, search, reschedule, or cancel any appointment — all from one dashboard.',
  },
  {
    icon: Layers,
    title: 'Reduced scheduling confusion',
    desc: 'Duplicate slots are blocked automatically, so two people never reserve the same time.',
  },
];

export default function Benefits() {
  return (
    <section className="bg-slate-50 py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="section-label">Why AppointEase</span>
          <h2 className="mt-4 font-display text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">
            Built to make scheduling effortless
          </h2>
          <p className="mt-3 text-slate-600">
            Practical benefits that keep the focus on what matters — your time.
          </p>
        </div>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {BENEFITS.map((b, i) => (
            <div
              key={b.title}
              className="animate-fade-up rounded-2xl border border-slate-200 bg-white p-6 transition-all duration-200 hover:shadow-md"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-md shadow-brand-600/20">
                <b.icon size={20} />
              </span>
              <h3 className="mt-4 font-display text-base font-bold text-slate-900">{b.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-slate-600">{b.desc}</p>
            </div>
          ))}

          <div className="flex flex-col justify-center rounded-2xl bg-gradient-to-br from-brand-600 to-brand-800 p-6 text-white">
            <h3 className="font-display text-lg font-bold">Ready when you are</h3>
            <p className="mt-1.5 text-sm leading-relaxed text-brand-100">
              AppointEase is a demo prototype showing a complete appointment-booking experience.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
